using System.Collections.Generic;

namespace Homework
{
    /// <summary>
    /// A Course can have many sections
    /// </summary>
    public class Course 
    {
        public string Title { get; set; }
        public int Number { get; set; }
    }
}